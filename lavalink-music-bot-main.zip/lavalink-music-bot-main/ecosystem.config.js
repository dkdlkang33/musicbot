module.exports = {
	apps: [
		{
			name: 'MusicBot',
			script: './dist/index.js'
		}
	]
};
