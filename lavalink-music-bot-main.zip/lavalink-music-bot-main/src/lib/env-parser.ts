import { isNullishOrEmpty } from '@sapphire/utilities';

export function envParseArray({ key, defaultValue }: { key: 'OWNERS'; defaultValue?: string[] }): string[] {
	const value = process.env[key];
	if (isNullishOrEmpty(value)) {
		if (defaultValue === undefined) throw new Error(`[ENV] ${key} - The key must be an array, but is empty or undefined.`);
		return defaultValue;
	}

	return value.split(' ');
}
